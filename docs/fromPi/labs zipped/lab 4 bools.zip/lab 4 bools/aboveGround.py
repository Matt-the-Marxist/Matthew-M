from mcpi.minecraft import Minecraft
import time as t
mc=Minecraft.create()

while True:
	pos = mc.player.getPos()
	aboveGround = pos.y >= mc.getHeight(pos.x, pos.z)
	if aboveGround:
		mc.postToChat("You are above ground")
		while aboveGround:
			t.sleep(0.001)
			pos = mc.player.getPos()
			aboveGround = pos.y >= mc.getHeight(pos.x, pos.z)
		mc.postToChat("you are no longer above ground")
