colorMode(HSB);
let bricks = [];

function setup() {
	createCanvas(480,320);
	paddle = new Paddle;
	puck = new Puck;
}

function draw() {
	background(0);
	paddle.show();
	puck.show();

	puck.checkPaddle();
}

function keyReleased(){
	if(keyCode == 32){
		return false;
	}
	paddle.move(0);
	
}

function keyPressed(){
	if (keyCode === RIGHT_ARROW){
		paddle.move(5);			
	} else if (keyCode === LEFT_ARROW){
		paddle.move(-5);
	} else if (keyCode == 32){
		if(puck.onPaddle){
			puck.shoot();
			puck.onPaddle = false;
		}
	}
	return false;
}