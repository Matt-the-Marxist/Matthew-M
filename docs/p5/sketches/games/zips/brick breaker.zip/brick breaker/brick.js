function brick (){
	
}