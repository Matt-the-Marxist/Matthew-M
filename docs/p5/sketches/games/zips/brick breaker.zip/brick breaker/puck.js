function Puck(){
	this.r = 5;
	this.x = width/2;
	this.y = height - (31 +  this.r);
	this.xspeed = 0;
	this.yspeed = 0;
	this.speed = 2.5;
	this.onPaddle = true;

	this.shoot = function(){
		this.angle =  random(-(Math.sqrt(2)/2),(Math.sqrt(2)/2));
		this.xspeed = this.speed * this.angle;
		this.yspeed = this.speed * -Math.sqrt(1-(this.angle * this.angle));
	}
	
	this.show = function(){
		fill(255);
		ellipse(this.x, this.y, 2*this.r, 2*this.r);
		
		this.x = this.x + this.xspeed;
		this.y = this.y + this.yspeed;
		
		if(this.x <= this.r||this.x >= width - this.r){
			this.xspeed *=-1;
		}
		
		if(this.y <= this.r){
			this.yspeed *= -1;
		}
		
		if(this.y >= height - this.r){
			this.xspeed = 0;
			this.yspeed = 0;
			this.y = height - (31 +  this.r);
			this.onPaddle = true;
		}
	}
	
	this.checkPaddle = function(){
		if( this.y >= height - (30+ this.r) && this.x >= paddle.x && this.x <= paddle.x + paddle.width){
			console.log("hi");
			this.yspeed *= -1;
		}
	}
}